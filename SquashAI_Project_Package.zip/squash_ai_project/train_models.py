"""
Train the two demo models:
1) Talent identification (text-based) -> 3-class classification
2) Match outcome prediction -> binary classification

Run:
  python train_models.py
Outputs:
  models/talent_model.pkl
  models/match_model.pkl
  models/metrics.json
"""
from pathlib import Path
import json
import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"
MODEL_DIR.mkdir(exist_ok=True)

def train_talent():
    athletes = pd.read_csv(DATA_DIR / "athletes_iran_squash.csv")
    X = athletes.drop(columns=["talent_label"])
    y = athletes["talent_label"]

    cat_cols = ["gender","province","dominant_hand","previous_sport"]
    num_cols = [c for c in X.columns if c not in cat_cols and c != "athlete_id"]

    preprocess = ColumnTransformer(
        transformers=[
            ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
            ("num", "passthrough", num_cols),
        ]
    )

    clf = RandomForestClassifier(
        n_estimators=260,
        random_state=42,
        class_weight="balanced",
        n_jobs=-1,
        max_depth=14,
    )
    model = Pipeline(steps=[("prep", preprocess), ("clf", clf)])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model.fit(X_train, y_train)
    acc = accuracy_score(y_test, model.predict(X_test))
    joblib.dump(model, MODEL_DIR / "talent_model.pkl")
    return float(acc)

def train_match():
    matches = pd.read_csv(DATA_DIR / "matches_iran_squash.csv")
    matches["rating_diff"] = matches["rating_a"] - matches["rating_b"]
    matches["age_diff"] = matches["age_a"] - matches["age_b"]
    matches["exp_diff"] = matches["experience_a"] - matches["experience_b"]

    X = matches[["home_a","rating_diff","age_diff","exp_diff"]]
    y = matches["winner_a"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    clf = RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1, max_depth=10)
    clf.fit(X_train, y_train)
    acc = accuracy_score(y_test, clf.predict(X_test))
    joblib.dump(clf, MODEL_DIR / "match_model.pkl")
    return float(acc)

if __name__ == "__main__":
    acc1 = train_talent()
    acc2 = train_match()
    metrics = {
        "talent_model_accuracy": acc1,
        "match_model_accuracy": acc2,
    }
    (MODEL_DIR / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Done. Metrics:", metrics)
