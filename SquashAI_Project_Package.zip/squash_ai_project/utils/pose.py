from __future__ import annotations
import os
import math
from dataclasses import dataclass
from typing import Dict, Any, Optional, List

import cv2
import numpy as np

# MediaPipe is lightweight and practical for demos
import mediapipe as mp

mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils

def _angle(a, b, c) -> float:
    """Angle ABC in degrees, where points are (x,y)."""
    ax, ay = a
    bx, by = b
    cx, cy = c
    ba = np.array([ax - bx, ay - by])
    bc = np.array([cx - bx, cy - by])
    denom = (np.linalg.norm(ba) * np.linalg.norm(bc)) + 1e-8
    cosang = np.clip(np.dot(ba, bc) / denom, -1.0, 1.0)
    return float(np.degrees(np.arccos(cosang)))

def analyze_video_pose(video_path: str, max_frames: int = 90, sample_every: int = 2) -> Dict[str, Any]:
    """
    Analyze a short squash video using pose estimation.
    Produces:
      - summary metrics (knee angle, hip stability proxy, motion proxy)
      - overlay video path (optional)
    To keep runtime fast: sample frames and cap max_frames.
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return {"summary": {"error": "cannot_open_video"}, "overlay_path": None}

    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 360)

    out_path = os.path.splitext(video_path)[0] + "_pose_overlay.mp4"
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(out_path, fourcc, float(fps), (width, height))

    knee_angles: List[float] = []
    hip_y: List[float] = []
    shoulder_y: List[float] = []
    motion: List[float] = []

    last_center = None
    frame_i = 0
    kept = 0

    with mp_pose.Pose(
        static_image_mode=False,
        model_complexity=1,
        enable_segmentation=False,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    ) as pose:

        while kept < max_frames:
            ok, frame = cap.read()
            if not ok:
                break

            if frame_i % sample_every != 0:
                frame_i += 1
                continue

            frame_i += 1
            kept += 1

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            res = pose.process(rgb)

            if res.pose_landmarks:
                lm = res.pose_landmarks.landmark

                # Use right side by default (works even if mirrored in many cases)
                RHIP = lm[mp_pose.PoseLandmark.RIGHT_HIP]
                RKNE = lm[mp_pose.PoseLandmark.RIGHT_KNEE]
                RANK = lm[mp_pose.PoseLandmark.RIGHT_ANKLE]
                RSHO = lm[mp_pose.PoseLandmark.RIGHT_SHOULDER]
                LSHO = lm[mp_pose.PoseLandmark.LEFT_SHOULDER]

                def to_xy(p):
                    return (p.x * width, p.y * height)

                hip = to_xy(RHIP)
                knee = to_xy(RKNE)
                ankle = to_xy(RANK)

                knee_ang = _angle(hip, knee, ankle)
                knee_angles.append(knee_ang)

                hip_y.append(hip[1])

                sho_mid = ((RSHO.x + LSHO.x) * 0.5 * width, (RSHO.y + LSHO.y) * 0.5 * height)
                shoulder_y.append(sho_mid[1])

                center = hip
                if last_center is not None:
                    motion.append(float(np.linalg.norm(np.array(center) - np.array(last_center))))
                last_center = center

                # draw overlay
                mp_drawing.draw_landmarks(
                    frame,
                    res.pose_landmarks,
                    mp_pose.POSE_CONNECTIONS,
                    landmark_drawing_spec=mp_drawing.DrawingSpec(thickness=2, circle_radius=2),
                    connection_drawing_spec=mp_drawing.DrawingSpec(thickness=2),
                )

                cv2.putText(frame, f"Knee angle: {knee_ang:.1f}", (20, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2, cv2.LINE_AA)
            else:
                cv2.putText(frame, "Pose not detected", (20, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2, cv2.LINE_AA)

            out.write(frame)

    cap.release()
    out.release()

    if len(knee_angles) == 0:
        return {"summary": {"error": "no_pose_detected"}, "overlay_path": None}

    knee_mean = float(np.mean(knee_angles))
    knee_std = float(np.std(knee_angles))

    # stability proxy: lower std of hip/shoulder y is more stable
    hip_std = float(np.std(hip_y)) if len(hip_y) > 1 else 0.0
    shoulder_std = float(np.std(shoulder_y)) if len(shoulder_y) > 1 else 0.0

    # motion proxy (not true speed, but frame-to-frame displacement in pixels)
    motion_mean = float(np.mean(motion)) if len(motion) else 0.0

    # quick heuristic score for demo purposes
    # In squash, lunges often show knee angles around ~90-140 depending on phase.
    knee_score = 1.0 - min(abs(knee_mean - 120.0) / 80.0, 1.0)
    stability_score = 1.0 - min((hip_std + shoulder_std) / (0.25 * (width + height)), 1.0)
    motion_score = min(motion_mean / 25.0, 1.0)

    overall = float(np.clip(0.45*knee_score + 0.35*stability_score + 0.20*motion_score, 0, 1))

    summary = {
        "frames_analyzed": int(kept),
        "knee_angle_mean_deg": round(knee_mean, 2),
        "knee_angle_std_deg": round(knee_std, 2),
        "hip_stability_std_px": round(hip_std, 2),
        "shoulder_stability_std_px": round(shoulder_std, 2),
        "motion_proxy_mean_px": round(motion_mean, 2),
        "pose_quality_score_0_1": round(overall, 3),
        "interpretation_fa": (
            "اگر زاویه زانو خیلی باز/بسته باشد یا پایداری کم باشد، روی footwork و lunge drills کار کن."
        ),
    }

    return {"summary": summary, "overlay_path": out_path}
