# 🏸 Squash AI — استعداد‌یابی و پیش‌بینی مسابقه با Pose Detection

این پروژه یک اپلیکیشن سبک و قابل ارائه برای درس «پروژه پایانی» است که طبق صورت‌مسئله:

- **مرحله ۱**: از **داده‌های متنی** برای استعداد‌یابی اسکواش استفاده می‌کند  
- **مرحله ۲**: از **تصویر/ویدئو + Pose Detection** برای تحلیل فرم حرکتی استفاده می‌کند  
- **مرحله ۳**: **پیش‌بینی نتیجه مسابقه** را انجام می‌دهد  

> مناسب برای قرار دادن در GitHub و LinkedIn.

---

## ✨ امکانات
- فرم استعداد‌یابی (سن/قد/وزن/تست‌های آمادگی جسمانی) → پیشنهاد سطح: مبتدی/متوسط/پیشرفته
- آپلود ویدئو کوتاه و تحلیل Pose با **MediaPipe** + خروجی ویدئوی overlay
- پیش‌بینی مسابقه (Win/Lose) با مدل سبک و سریع
- دیتاست نمونه ایران‌محور + مدل‌های آموزش‌دیده آماده

---

## 📁 ساختار پوشه‌ها
```
squash_ai_project/
  app.py
  train_models.py
  requirements.txt
  data/
    athletes_iran_squash.csv
    matches_iran_squash.csv
  models/
    talent_model.pkl
    match_model.pkl
    metrics.json
  utils/
    pose.py
```

---

## 🚀 اجرا (Local)
1) نصب وابستگی‌ها:
```bash
pip install -r requirements.txt
```

2) اجرای اپلیکیشن:
```bash
streamlit run app.py
```

---

## 🧠 آموزش مجدد مدل‌ها (اختیاری)
اگر خواستی مدل‌ها را دوباره train کنی:
```bash
python train_models.py
```

---

## 📊 دیتاست (Iran-oriented)
- `athletes_iran_squash.csv`: پروفایل ورزشکار + تست‌های آمادگی جسمانی + برچسب سطح
- `matches_iran_squash.csv`: مسابقات ساختاریافته + ویژگی‌های ساده برای پیش‌بینی

> برای گزارش، می‌تونی توضیح بدی داده‌ها «سینتتیک اما realistic» ساخته شده‌اند و ویژگی‌ها مطابق فرم‌های رایج تست آمادگی جسمانی در ایران تنظیم شده‌اند.

---

## 🔎 نکته‌های سرعت و حجم
- پردازش ویدئو محدود به `max_frames` و `sample_every` است تا سریع باشد.
- مدل‌ها RandomForest با اندازه کنترل‌شده‌اند تا حجم و زمان inference پایین بماند.

---

## 🧾 متن آماده برای LinkedIn
**Smart Squash Talent Identification & Match Prediction System**

I built an AI-powered application that identifies athletic talent in squash using text-based fitness data, analyzes movement technique using pose detection from videos, and predicts match outcomes using machine learning.

Tech: Python, Streamlit, OpenCV, MediaPipe, Scikit-learn

---

## License
MIT
