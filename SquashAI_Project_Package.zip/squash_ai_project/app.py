import streamlit as st
import pandas as pd
import numpy as np
import joblib
from pathlib import Path
from utils.pose import analyze_video_pose

APP_TITLE = "Squash AI - استعداد‌یابی و پیش‌بینی مسابقه"

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"

@st.cache_resource
def load_models():
    talent = joblib.load(MODEL_DIR / "talent_model.pkl")
    match = joblib.load(MODEL_DIR / "match_model.pkl")
    return talent, match

talent_model, match_model = load_models()

st.set_page_config(page_title=APP_TITLE, page_icon="🏸", layout="wide")
st.title("🏸 " + APP_TITLE)
st.caption("مرحله ۱: متن | مرحله ۲: ویدئو + Pose Detection | مرحله ۳: پیش‌بینی نتیجه مسابقه")

tabs = st.tabs(["۱) استعداد‌یابی (متن)", "۲) تحلیل ویدئو (Pose)", "۳) پیش‌بینی مسابقه", "دیتاست و خروجی‌ها"])

with tabs[0]:
    st.subheader("مرحله ۱: استعداد‌یابی بر اساس داده‌های متنی")
    col1, col2, col3 = st.columns(3)
    with col1:
        age = st.number_input("سن", min_value=8, max_value=60, value=18)
        gender = st.selectbox("جنسیت", ["زن", "مرد"])
        province = st.selectbox("استان", ["تهران","اصفهان","فارس","خراسان رضوی","آذربایجان شرقی","البرز","گیلان","مازندران","کرمان","قم","یزد","کرمانشاه"])
        dominant_hand = st.selectbox("دست غالب", ["راست","چپ"])
    with col2:
        height_cm = st.number_input("قد (cm)", min_value=120.0, max_value=220.0, value=170.0, step=0.5)
        weight_kg = st.number_input("وزن (kg)", min_value=30.0, max_value=140.0, value=65.0, step=0.5)
        previous_sport = st.selectbox("سابقه ورزشی اصلی", ["فوتبال","بسکتبال","والیبال","تنیس","بدمینتون","کاراته","شنا","دوومیدانی","بدون سابقه"])
        experience_years = st.number_input("سابقه تمرین (سال)", min_value=0, max_value=20, value=2)
    with col3:
        weekly_training_sessions = st.number_input("تعداد جلسات تمرین در هفته", min_value=0, max_value=14, value=3)
        agility_test_s = st.number_input("تست چابکی (ثانیه) - هرچه کمتر بهتر", min_value=8.0, max_value=25.0, value=15.0, step=0.1)
        sprint20m_s = st.number_input("سرعت ۲۰ متر (ثانیه) - هرچه کمتر بهتر", min_value=2.5, max_value=6.5, value=4.0, step=0.05)
        beep_test_level = st.number_input("تست بوق (Level) - هرچه بیشتر بهتر", min_value=1.0, max_value=15.0, value=8.0, step=0.1)
        reaction_time_ms = st.number_input("زمان واکنش (ms) - هرچه کمتر بهتر", min_value=150, max_value=600, value=320, step=5)

    if st.button("محاسبه استعداد"):
        row = pd.DataFrame([{
            "athlete_id": "NEW",
            "age": int(age),
            "gender": gender,
            "province": province,
            "height_cm": float(height_cm),
            "weight_kg": float(weight_kg),
            "dominant_hand": dominant_hand,
            "previous_sport": previous_sport,
            "experience_years": int(experience_years),
            "weekly_training_sessions": int(weekly_training_sessions),
            "agility_test_s": float(agility_test_s),
            "sprint20m_s": float(sprint20m_s),
            "beep_test_level": float(beep_test_level),
            "reaction_time_ms": int(reaction_time_ms),
        }])
        pred = talent_model.predict(row)[0]
        proba = talent_model.predict_proba(row)[0]
        classes = talent_model.classes_

        st.success(f"✅ سطح پیشنهادی برای اسکواش: **{pred}**")
        st.write("احتمال هر کلاس:")
        st.dataframe(pd.DataFrame({"کلاس": classes, "احتمال": np.round(proba, 3)}), use_container_width=True)

        if pred == "مبتدی":
            st.info("پیشنهاد تمرین: تمرکز بر چابکی، footwork، و بهبود زمان واکنش (drills کوتاه ۱۰-۱۵ دقیقه‌ای).")
        elif pred == "متوسط":
            st.info("پیشنهاد تمرین: ترکیب footwork + تمرین ضربه forehand/backhand، و بازی‌های کوتاه برای افزایش تصمیم‌گیری.")
        else:
            st.info("پیشنهاد تمرین: برنامه‌ی تخصصی شامل HIIT، تحلیل ویدئو، و تمرکز روی تاکتیک‌های rally و کنترل T.")

with tabs[1]:
    st.subheader("مرحله ۲: Pose Detection روی ویدئو (سبک و سریع)")
    st.write("ویدئو کوتاه (ترجیحا ۱۰ تا ۲۰ ثانیه) از حرکت ضربه یا footwork آپلود کن.")
    video_file = st.file_uploader("آپلود ویدئو (mp4/mov)", type=["mp4","mov","m4v","avi"])

    max_frames = st.slider("حداکثر فریم برای پردازش (برای سرعت)", min_value=30, max_value=240, value=90, step=10)
    sample_every = st.slider("نمونه‌برداری هر چند فریم یکبار", min_value=1, max_value=8, value=2, step=1)

    if video_file is not None:
        tmp_path = BASE_DIR / "tmp_video"
        tmp_path.mkdir(exist_ok=True)
        vid_path = tmp_path / video_file.name
        vid_path.write_bytes(video_file.read())

        if st.button("تحلیل Pose"):
            with st.spinner("در حال پردازش..."):
                result = analyze_video_pose(str(vid_path), max_frames=max_frames, sample_every=sample_every)
            st.success("✅ تحلیل انجام شد")
            st.json(result["summary"])

            if result.get("overlay_path"):
                st.video(result["overlay_path"])

            st.markdown("**شاخص‌های پیشنهادی اسکواش**")
            st.write("- زاویه زانو (خم شدن مناسب برای lunges)")
            st.write("- پایداری لگن/شانه (کنترل بدن)")
            st.write("- سرعت نسبی حرکت (با اختلاف فریم‌ها)")

with tabs[2]:
    st.subheader("مرحله ۳: پیش‌بینی نتیجه مسابقه")
    st.caption("برای دمو: از rating تخمینی (۰ تا ۱) استفاده می‌کنیم. اگر Pose هم داشته باشی می‌تونی rating رو دقیق‌تر کنی.")

    c1, c2 = st.columns(2)
    with c1:
        rating_a = st.slider("rating بازیکن A", 0.0, 1.0, 0.55, 0.01)
        age_a = st.number_input("سن A", min_value=8, max_value=60, value=20)
        exp_a = st.number_input("سابقه A (سال)", min_value=0, max_value=20, value=3)
        home_a = st.selectbox("میزبان A است؟", [0,1], format_func=lambda x: "بله" if x==1 else "خیر")
    with c2:
        rating_b = st.slider("rating بازیکن B", 0.0, 1.0, 0.50, 0.01)
        age_b = st.number_input("سن B", min_value=8, max_value=60, value=22)
        exp_b = st.number_input("سابقه B (سال)", min_value=0, max_value=20, value=2)

    if st.button("پیش‌بینی"):
        X = pd.DataFrame([{
            "home_a": int(home_a),
            "rating_diff": float(rating_a - rating_b),
            "age_diff": int(age_a - age_b),
            "exp_diff": int(exp_a - exp_b),
        }])
        pred = int(match_model.predict(X)[0])
        proba = match_model.predict_proba(X)[0]
        st.success(f"🏁 پیش‌بینی: {'برد بازیکن A' if pred==1 else 'برد بازیکن B'}")
        st.write({"احتمال برد A": float(np.round(proba[1],3)), "احتمال برد B": float(np.round(proba[0],3))})

with tabs[3]:
    st.subheader("دیتاست‌ها و خروجی‌ها")
    st.write("این پروژه شامل دو دیتاست نمونه (ساخت ایران‌محور) است:")
    st.code("data/athletes_iran_squash.csv\ndata/matches_iran_squash.csv")
    st.write("و دو مدل آموزش‌دیده:")
    st.code("models/talent_model.pkl\nmodels/match_model.pkl")
    st.write("می‌تونی فایل‌ها رو از ریپازیتوری GitHub یا خروجی zip دانلود کنی.")
